package mx.edu.ittepic.ladm_u3_pract2

import android.app.Dialog
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.Toast
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    var baseRemota = FirebaseFirestore.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        insertar.setOnClickListener {
            insertarR()
        }
        consultar.setOnClickListener {
            creacionDialog()
        }


    }

    private fun creacionDialog() {
        var dialogo = Dialog(this)

        dialogo.setContentView(R.layout.consulta)

        var valor = dialogo.findViewById<EditText>(R.id.valor)
        var posicion = dialogo.findViewById<Spinner>(R.id.clave)
        var buscar = dialogo.findViewById<Button>(R.id.buscar)
        var cerrar = dialogo.findViewById<Button>(R.id.cerrar)

        dialogo.show()
        cerrar.setOnClickListener {
            dialogo.dismiss()
        }
        buscar.setOnClickListener {
            if(valor.text.isEmpty()){
                Toast.makeText(this,"PON UN VALOR PARA BUSCAR", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            consultaDeDatos(valor.text.toString(),posicion.selectedItemPosition)
            dialogo.dismiss()
        }
    }

    private fun consultaDeDatos(valor: String, clave: Int) {
        when(clave){
            0->{consultaNombre(valor)}
            1->{consultaCelular(valor)}
        }

    }

    private fun consultaNombre(valor: String) {
        baseRemota.collection("restaurante")
            .whereEqualTo("nombre",valor)
            .addSnapshotListener { querySnapshot, firebaseFirestoreException ->
                if (firebaseFirestoreException !=null){
                    resultado.setText("NO HAY CONEXION")
                    return@addSnapshotListener
                }
                var res = ""
                for(document in querySnapshot!!){
                    res += "ID"+document.id+"\nNombre: "+document.getString("nombre")+
                            "\nDomicilio: "+document.getString("domicilio")+
                            "\nCelular: "+document.getString("celular")+
                            "\n\nDescripcion: "+document.get("pedido.descripcion")+
                            "\nPrecio: "+document.get("pedido.precio")+
                            "\nCantidad: "+document.get("pedido.cantidad")+
                            "\nEstado: "+document.get("pedido.estado")
                }
                if(res.indexOf("null")>=0) {
                    res = res.substring(0,res.indexOf("pedido"))
                }
                resultado.setText(res)
            }

    }
    private fun consultaCelular(valor: String){
        baseRemota.collection("restaurante")
            .whereEqualTo("celular",valor)
            .addSnapshotListener { querySnapshot, firebaseFirestoreException ->
                if (firebaseFirestoreException !=null){
                    resultado.setText("NO HAY CONEXION")
                    return@addSnapshotListener
                }
                var res = ""
                for(document in querySnapshot!!){
                    res += "ID"+document.id+"\nNombre: "+document.getString("nombre")+
                            "\nDomicilio: "+document.getString("domicilio")+
                            "\nCelular: "+document.getString("celular")+
                            "\n\nDescripcion: "+document.get("pedido.descripcion")+
                            "\nPrecio: "+document.get("pedido.precio")+
                            "\nCantidad: "+document.get("pedido.cantidad")+
                            "\nEstado: "+document.get("pedido.estado")
                }
                if(res.indexOf("null")>=0) {
                    res = res.substring(0,res.indexOf("pedido"))
                }
                resultado.setText(res)
            }

    }

    private fun insertarR() {
        var data = hashMapOf(
            "nombre" to nombreCliente.text.toString(),
            "domicilio" to domicilioCliente.text.toString(),
            "celular" to celularCliente.text.toString()
        )
        baseRemota.collection("restaurante")
            .add(data)
            .addOnSuccessListener {
                if (estado.isChecked==true) {
                    var pedido = hashMapOf(
                        "estado" to estado.text.toString().toBoolean(),
                        "descripcion" to descripcionPedido.text.toString(),
                        "precio" to precioPedido.text.toString().toFloat(),
                        "cantidad" to cantidadPedido.text.toString().toInt()

                    )
                    baseRemota.collection("restaurante")
                        .document(it.id)
                        .update("pedido", pedido as Map<String, Any>)
                }
                Toast.makeText(this,"Inserccion exitosa", Toast.LENGTH_LONG)
                    .show()
                nombreCliente.setText(""); domicilioCliente.setText(""); celularCliente.setText(""); descripcionPedido.setText("");
                precioPedido.setText("");cantidadPedido.setText("");
            }
            .addOnFailureListener {
                Toast.makeText(this, "No logro guardarse", Toast.LENGTH_LONG)
                    .show()
            }
    }
}
